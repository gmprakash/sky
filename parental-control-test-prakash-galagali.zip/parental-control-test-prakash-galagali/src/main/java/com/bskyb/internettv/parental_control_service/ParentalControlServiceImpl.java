package com.bskyb.internettv.parental_control_service;

import static com.bskyb.internettv.parental_control_service.ParentalControlLevel.ofLevelCode;

import com.bskyb.internettv.thirdparty.MovieService;
import com.bskyb.internettv.thirdparty.TechnicalFailureException;
import com.bskyb.internettv.thirdparty.TitleNotFoundException;
import org.apache.commons.lang3.StringUtils;

public class ParentalControlServiceImpl implements ParentalControlService {

    private final MovieService movieService;

    public ParentalControlServiceImpl(MovieService movieService) {
        this.movieService = movieService;
    }

    public boolean canWatchMovie(String customerParentalControlLevel, String movieId) throws Exception {
    	
        validateInput(customerParentalControlLevel, movieId);
        String controlLevelResponse;
        try {
            controlLevelResponse = movieService.getParentalControlLevel(movieId);
        } catch (TitleNotFoundException titleNotFoundException) {
            throw new ParentControlLevelException("Requested title not found: "+movieId);
        } catch (TechnicalFailureException technicalFailureException) {
            throw new ParentControlLevelException("Due to technical issues you cannot watch the movie right now, please try later: "+movieId);
        }

        return isResponseLTERequestedLevel(customerParentalControlLevel, controlLevelResponse);
    }

    private void validateInput(String customerParentalControlLevel, String movieId) throws ParentControlLevelException {
        if (StringUtils.isBlank(customerParentalControlLevel)) {
            throw new ParentControlLevelException("Requested parental control level is empty");
        }
        if (StringUtils.isBlank(movieId)) {
            throw new ParentControlLevelException("Requested movie ID is empty");
        }
    }

    private boolean isResponseLTERequestedLevel(String customerParentalControlLevel, String controlLevelResponse) throws ParentControlLevelException {
        return ofLevelCode(controlLevelResponse).compareTo(ofLevelCode(customerParentalControlLevel)) <= 0;
    }
}
