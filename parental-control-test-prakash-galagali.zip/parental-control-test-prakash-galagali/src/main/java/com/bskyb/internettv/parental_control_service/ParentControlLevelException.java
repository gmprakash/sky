package com.bskyb.internettv.parental_control_service;

public class ParentControlLevelException extends Exception {
	private static final long serialVersionUID = -6472397190035353184L;

	public ParentControlLevelException(String message) {
        super(message);
    }
}
