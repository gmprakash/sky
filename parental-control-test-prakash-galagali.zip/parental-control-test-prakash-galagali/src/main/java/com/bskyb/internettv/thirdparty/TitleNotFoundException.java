package com.bskyb.internettv.thirdparty;

public class TitleNotFoundException extends Exception {
}
