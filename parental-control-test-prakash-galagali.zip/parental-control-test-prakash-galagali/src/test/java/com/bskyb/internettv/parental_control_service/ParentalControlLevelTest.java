package com.bskyb.internettv.parental_control_service;

import static org.junit.Assert.*;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class ParentalControlLevelTest {

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
    public void shouldReturnLevelCode_U() throws Exception {
        ParentalControlLevel parentalControlLevel = ParentalControlLevel.ofLevelCode("U");
        assertEquals(ParentalControlLevel.U, parentalControlLevel);
    }

    @Test
    public void shouldThrowExceptionWhenLevelNotFound() throws Exception {
        thrown.expect(ParentControlLevelException.class);
        thrown.expectMessage("Failed to map the control level to 20");
        ParentalControlLevel.ofLevelCode("20");
    }

}
