package com.bskyb.internettv.parental_control_service;


import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.bskyb.internettv.thirdparty.MovieService;
import com.bskyb.internettv.thirdparty.TechnicalFailureException;
import com.bskyb.internettv.thirdparty.TitleNotFoundException;

@RunWith(MockitoJUnitRunner.class)
public class ParentalControlServiceTest {

    private static final String MOVIE_ID = "movie-007";

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Mock
    private MovieService mockMovieService;
    
    private ParentalControlService parentalControlService;

    @Before
    public void before() {
        parentalControlService = new ParentalControlServiceImpl(mockMovieService);
    }

    @Test
    public void whenControlLevelEqualToCustomerPrefThenReturnTrue() throws Exception {
        when(mockMovieService.getParentalControlLevel(MOVIE_ID)).thenReturn("PG");

        boolean canWatchMovie = parentalControlService.canWatchMovie("PG", MOVIE_ID);
        verify(mockMovieService,times(1)).getParentalControlLevel(MOVIE_ID);
        assertTrue(canWatchMovie);
    }

    @Test
    public void whenControlLevelLessThanCustomerPrefThenReturnTrue() throws Exception {
        when(mockMovieService.getParentalControlLevel(MOVIE_ID)).thenReturn("12");

        boolean canWatchMovie = parentalControlService.canWatchMovie("15", MOVIE_ID);
        verify(mockMovieService,times(1)).getParentalControlLevel(MOVIE_ID);
        assertTrue(canWatchMovie);
    }

    @Test
    public void whenControlLevelMoreThanCustomerPrefReturnFalse() throws Exception {
        when(mockMovieService.getParentalControlLevel(MOVIE_ID)).thenReturn("15");

        boolean canWatchMovie = parentalControlService.canWatchMovie("PG", MOVIE_ID);
        verify(mockMovieService,times(1)).getParentalControlLevel(MOVIE_ID);
        assertFalse(canWatchMovie);
    }

    @Test
    public void whenParentalControlLevelIsNullThenThrowException() throws Exception {
        thrown.expect(ParentControlLevelException.class);
        thrown.expectMessage("Requested parental control level is empty");

        parentalControlService.canWatchMovie(null, MOVIE_ID);        
    }

    @Test
    public void whenParentalControlLevelIsEmptyThenThrowException() throws Exception {
        thrown.expect(ParentControlLevelException.class);
        thrown.expectMessage("Requested parental control level is empty");

        parentalControlService.canWatchMovie("", MOVIE_ID);        
    }
    
    @Test
    public void whenMovieIdIsNullThenThrowException() throws Exception {
        thrown.expect(ParentControlLevelException.class);
        thrown.expectMessage("Requested movie ID is empty");

        parentalControlService.canWatchMovie("PG", null);
    }

    @Test
    public void whenMovieIdIsEmptyThenThrowException() throws Exception {
        thrown.expect(ParentControlLevelException.class);
        thrown.expectMessage("Requested movie ID is empty");

        parentalControlService.canWatchMovie("PG", "");
    }
    
    @Test
    public void whenTitleNotFoundThenThrowException() throws Exception {
        thrown.expect(ParentControlLevelException.class);
        thrown.expectMessage("Requested title not found: " + MOVIE_ID);

        when(mockMovieService.getParentalControlLevel(MOVIE_ID)).thenThrow(new TitleNotFoundException());

        parentalControlService.canWatchMovie("12", MOVIE_ID);
    }

    @Test
    public void whenTechnicalFailureExceptionThenThrowException() throws Exception {
        thrown.expect(ParentControlLevelException.class);
        thrown.expectMessage("Due to technical issues you cannot watch the movie right now, please try later: " + MOVIE_ID);

        when(mockMovieService.getParentalControlLevel(MOVIE_ID)).thenThrow(new TechnicalFailureException());

        parentalControlService.canWatchMovie("12", MOVIE_ID);
    }

    @Test
    public void whenRequestedParentalLevelNotValidThenThrowException() throws Exception {
        thrown.expect(ParentControlLevelException.class);
        thrown.expectMessage("Failed to map the control level to 20");

        when(mockMovieService.getParentalControlLevel(MOVIE_ID)).thenReturn("15");

        parentalControlService.canWatchMovie("20", MOVIE_ID);
    }
}
